package com.sample.meetup2;

import android.content.Context;
import android.provider.SyncStateContract;
import android.support.annotation.NonNull;
import android.support.v7.view.menu.MenuView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import javax.xml.transform.Result;

public class MenuAdapter  extends RecyclerView.Adapter<MenuAdapter.ViewHolder> {
    Context context;
    private List<Movie> list;

    public MenuAdapter(Context context, List<Movie> list) {
        this.context = context;
        this.list = list;

    }

    @NonNull
    @Override
    public MenuAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu, parent, false);
        final MenuAdapter.ViewHolder holder = new MenuAdapter.ViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MenuAdapter.ViewHolder holder, int position) {
        Movie result = list.get(holder.getAdapterPosition());
        holder.tvPrice.setText(result.getTitle());
        holder.tvName.setText(result.getReleaseDate());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView ivMenu;
        public TextView tvName;
        public TextView tvPrice;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivMenu = itemView.findViewById(R.id.ivMenu);
            tvName = itemView.findViewById(R.id.tvName);
            tvPrice = itemView.findViewById(R.id.tvPrice);
        }
    }
}
